<?php
/**
 * Created by PhpStorm.
 * User: ruchir
 * Date: 4/7/2015
 * Time: 12:48 PM
 */

return [
    'store_record_msg' => 'Stored Successfully!!!',
    'update_record_msg' => 'Updated Successfully!!!',
    'delete_record_msg' => 'Deleted Successfully!!!',
    'error_record_msg' => 'Something went wrong. Please retry with proper data!',


    'marketing_admin_id' => 1,
];