<div class="bg-light lter b-b wrapper-md">
    <h1 class="m-n font-thin h3">Users To Approve</h1>
</div>


<div class="wrapper-md" ng-init="index()">
    <div flash-message="5000"></div>

    <div data-ng-include="approve_user_view_file" class="fade-in-up-big "></div>

</div>