<div class="aside-wrap">
  <!-- if you want to use a custom scroll when aside fixed, use the slimScroll
    <div class="navi-wrap" ui-jq="slimScroll" ui-options="{height:'100%', size:'8px'}">
  -->
  <div class="navi-wrap">

    <!-- nav -->
    <nav ui-nav class="navi" ng-include="'<?= url('navView'); ?>'"></nav>
    <!-- nav -->

  </div>
</div>