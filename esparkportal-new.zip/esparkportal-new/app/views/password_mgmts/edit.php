<div class="bg-light lter b-b wrapper-md">
    <h1 class="m-n font-thin h3">Edit Domain</h1>
</div>
<div class="wrapper-md" ng-init="editData()">
    <div flash-message="5000"></div>
    <div ng-include="password_mgmts_edit_file"></div>
</div>