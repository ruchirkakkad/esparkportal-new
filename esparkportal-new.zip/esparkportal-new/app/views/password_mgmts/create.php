<div class="bg-light lter b-b wrapper-md">
  <h1 class="m-n font-thin h3">Add Domain</h1>
</div>
<div class="wrapper-md" ng-init="resetData()">
<div flash-message="5000" ></div>
  <div ng-include="password_mgmts_create_file">

  </div>
</div>