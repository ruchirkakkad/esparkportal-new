<div class="bg-light lter b-b wrapper-md">
  <h1 class="m-n font-thin h3">Details</h1>
</div>
<div class="wrapper-md" ng-init="showData()">
<div flash-message="5000" ></div>
  <div ng-include="password_mgmts_show_file">

  </div>
</div>