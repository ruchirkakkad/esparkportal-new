<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
            Hello, {{$user->first_name}} {{$user->last_name}}
            
		<h4>Thank you...!</h4>

	
	</body>
</html>
