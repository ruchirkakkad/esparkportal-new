<div class="bg-light lter b-b wrapper-md">
    <h1 class="m-n font-thin h3">Report</h1>
</div>
<div class="wrapper-md" ng-init="userWiseChart()">
    <div ng-include="marketing_report_chart_view" class="fade-in-down-big ">

    </div>
</div>
</div>