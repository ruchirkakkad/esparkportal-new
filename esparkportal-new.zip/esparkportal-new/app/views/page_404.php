<div class="container w-xxl w-auto-xs" ng-init="app.settings.container = false;">
  <div class="text-center m-b-lg">
    <h1 class="text-shadow text-white">Ooopss!!</h1>
  </div>
  <div class="list-group bg-info auto m-b-sm m-b-lg">
    <a href="#/" class="list-group-item">
      <i class="fa fa-chevron-right text-muted"></i>
      <i class="fa fa-fw fa-mail-forward m-r-xs"></i> Goto application
    </a>
    <a ui-sref="access.signin" class="list-group-item">
      <i class="fa fa-chevron-right text-muted"></i>
      <i class="fa fa-fw fa-sign-in m-r-xs"></i> Sign in
    </a>
    <a ui-sref="access.signup" class="list-group-item">
      <i class="fa fa-chevron-right text-muted"></i>
      <i class="fa fa-fw fa-unlock-alt m-r-xs"></i> Sign up
    </a>
  </div>
</div>