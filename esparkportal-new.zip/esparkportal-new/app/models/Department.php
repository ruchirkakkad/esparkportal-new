<?php

class Department extends \Eloquent {
	protected $fillable = [];
          protected $primaryKey = "departments_id";

}