<?php

class Role extends \Eloquent {
	protected $fillable = [];
}