<?php

class Module extends \Eloquent {
	protected $fillable = [];
    protected $primaryKey = 'module_id';
}