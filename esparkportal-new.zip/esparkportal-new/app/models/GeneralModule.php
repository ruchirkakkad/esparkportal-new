<?php

class GeneralModule extends \Eloquent {
	protected $fillable = [];
}